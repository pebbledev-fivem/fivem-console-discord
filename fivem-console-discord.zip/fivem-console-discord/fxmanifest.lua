fx_version 'cerulean'
game 'gta5'

author 'You'
description 'Forwards FiveM server console output to a Discord channel via webhook'
version '1.0.0'

server_scripts {
    'server/config.lua',
    'server/main.lua'
}
