Config = {}

-- Your Discord webhook URL (Server Settings -> Integrations -> Webhooks -> New Webhook -> Copy URL)
Config.WebhookURL = "https://discord.com/api/webhooks/XXXXXXXXXXXX/YYYYYYYYYYYYYYYYYYYYYYYY"

-- Bot appearance in Discord
Config.Username  = "FiveM Console"
Config.AvatarURL = "https://i.imgur.com/your-avatar.png" -- optional

-- How often (in ms) to flush queued lines to Discord.
-- Discord webhooks rate-limit at ~5 requests / 2s per webhook, so don't go too low.
Config.FlushInterval = 2000

-- Max characters per Discord message (Discord hard limit is 2000)
Config.MaxMessageLength = 1900

-- Which output channels to capture. FiveM exposes the print buffer; we also
-- listen for chat, server start/stop, player connect/disconnect, and errors.
Config.Capture = {
    prints       = true,  -- print() / Citizen.Trace / generic console output
    playerJoins  = true,
    playerLeaves = true,
    chatMessages = true,
    resourceState = true, -- resource start/stop/error
}

-- Skip lines that contain any of these substrings (reduces noise / keeps secrets out)
Config.Blacklist = {
    "license:",
    "steam:",
    "discord:",
    "xbl:",
    "live:",
    "ip:",
    "token",
    "password",
    "Config.WebhookURL",
}
