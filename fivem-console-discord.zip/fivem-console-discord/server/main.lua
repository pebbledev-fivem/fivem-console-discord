-- =====================================================================
-- FiveM Console -> Discord forwarder
-- =====================================================================
-- Hooks server console output, batches it, and posts to a Discord
-- webhook on a fixed interval. Also captures join/leave/chat/resource
-- lifecycle events.
-- =====================================================================

local queue = {}
local queueLock = false

-- ---------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------

local function isBlacklisted(line)
    if not line then return true end
    local lower = line:lower()
    for _, term in ipairs(Config.Blacklist) do
        if lower:find(term:lower(), 1, true) then
            return true
        end
    end
    return false
end

local function stripColorCodes(s)
    -- FiveM console uses ^1, ^2 etc. for color; strip for clean Discord output
    return (s:gsub("%^%d", ""))
end

local function enqueue(line)
    if not line or line == "" then return end
    line = stripColorCodes(line)
    if isBlacklisted(line) then return end
    queue[#queue + 1] = line
end

-- ---------------------------------------------------------------------
-- Discord sender
-- ---------------------------------------------------------------------

local function sendToDiscord(content)
    if not Config.WebhookURL or Config.WebhookURL:find("XXXXXXXXXXXX") then
        print("[console-discord] WARNING: webhook URL is not configured.")
        return
    end

    PerformHttpRequest(Config.WebhookURL, function(status, _, _)
        if status ~= 200 and status ~= 204 then
            -- Don't enqueue this error or we'll loop forever
            print(("[console-discord] Discord returned HTTP %s"):format(tostring(status)))
        end
    end, "POST", json.encode({
        username   = Config.Username,
        avatar_url = Config.AvatarURL,
        content    = content,
        -- Suppress @everyone / @here / role pings from leaking through console output
        allowed_mentions = { parse = {} },
    }), { ["Content-Type"] = "application/json" })
end

-- Build one or more Discord messages from the queue, respecting the char limit.
local function flushQueue()
    if queueLock then return end
    if #queue == 0 then return end
    queueLock = true

    local buffer = {}
    local current = ""

    for _, line in ipairs(queue) do
        -- +5 for the ``` fence + newline overhead
        if #current + #line + 5 > Config.MaxMessageLength then
            buffer[#buffer + 1] = current
            current = ""
        end
        current = current == "" and line or (current .. "\n" .. line)
    end
    if current ~= "" then buffer[#buffer + 1] = current end

    queue = {}

    for _, chunk in ipairs(buffer) do
        sendToDiscord("```\n" .. chunk .. "\n```")
    end

    queueLock = false
end

-- ---------------------------------------------------------------------
-- Console capture
--
-- FiveM doesn't expose a simple "on every print" hook server-side, but
-- registering a `__cfx_internal:serverPrint` handler isn't supported either.
-- The reliable approach is to wrap `print` and Citizen.Trace at the global
-- level. Anything calling `print` from any resource will then be captured.
-- ---------------------------------------------------------------------

if Config.Capture.prints then
    local originalPrint = print
    function print(...)
        local args = { ... }
        local parts = {}
        for i = 1, select("#", ...) do
            parts[i] = tostring(args[i])
        end
        local line = table.concat(parts, "\t")
        enqueue(line)
        originalPrint(...)
    end

    -- Citizen.Trace is what many FiveM internals use; wrap if available
    if Citizen and Citizen.Trace then
        local originalTrace = Citizen.Trace
        Citizen.Trace = function(msg)
            enqueue(tostring(msg))
            originalTrace(msg)
        end
    end
end

-- ---------------------------------------------------------------------
-- Event hooks
-- ---------------------------------------------------------------------

if Config.Capture.playerJoins then
    AddEventHandler("playerJoining", function()
        local src = source
        local name = GetPlayerName(src) or "Unknown"
        enqueue(("[JOIN]    %s (id=%s)"):format(name, src))
    end)
end

if Config.Capture.playerLeaves then
    AddEventHandler("playerDropped", function(reason)
        local src = source
        local name = GetPlayerName(src) or "Unknown"
        enqueue(("[LEAVE]   %s (id=%s) — %s"):format(name, src, reason or "no reason"))
    end)
end

if Config.Capture.chatMessages then
    AddEventHandler("chatMessage", function(src, name, msg)
        enqueue(("[CHAT]    %s: %s"):format(name or GetPlayerName(src) or "?", msg or ""))
    end)
end

if Config.Capture.resourceState then
    AddEventHandler("onResourceStart", function(name)
        enqueue(("[RESOURCE] started: %s"):format(name))
    end)
    AddEventHandler("onResourceStop", function(name)
        enqueue(("[RESOURCE] stopped: %s"):format(name))
    end)
end

-- ---------------------------------------------------------------------
-- Periodic flusher
-- ---------------------------------------------------------------------

CreateThread(function()
    while true do
        Wait(Config.FlushInterval)
        local ok, err = pcall(flushQueue)
        if not ok then
            -- Avoid recursion: write directly to original console only
            io.write(("[console-discord] flush error: %s\n"):format(tostring(err)))
        end
    end
end)

-- Send one line at startup so you know it's alive
CreateThread(function()
    Wait(1500)
    enqueue(("[console-discord] resource started at %s"):format(os.date("%Y-%m-%d %H:%M:%S")))
end)
